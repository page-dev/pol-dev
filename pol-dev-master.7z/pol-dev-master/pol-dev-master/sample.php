<?php include 'templates/header.php';?>
<?php include 'templates/nav.php';?>



<div class = "container">
    <div class = "imgDescription">
    
        <div>
        <h1>OPERATION TITLE</h1>
            <h2><strong>Solution</strong></h2>
            <p>Sample txt</p>
            <p>$length = 10;<br>$width = 5;<br>$area = $length * $width;<br>echo "$area"</p>
        </div>
        <img src="assets/ao1.png" alt="">
    </div>
</div>

<?php
    $a = 0;
    $b = 20;

    $c = ($a > $b) ? "a is bigger than b" : "b is bigger than a";
    echo "$c"
?>



<?php include 'templates/footer.php';?>