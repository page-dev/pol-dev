<?php include 'templates/header.php';?>
<?php include 'templates/nav.php';?>

    <div class ="welcome">
        <h1><strong><span class="welcomeSize">Welcome</span><br>to my landing page</strong></h1>
    </div>

<?php include 'templates/footer.php';?>